# Prey Puppet Module for Boxen
[![Build Status](https://travis-ci.org/pauloconnor/puppet-prey.png?branch=master)](https://travis-ci.org/pauloconnor/puppet-prey)

Installs [Prey](http://preyproject.com/) app

## Usage

```puppet
include prey
```

## Required Puppet Modules

* boxen
* stdlib
